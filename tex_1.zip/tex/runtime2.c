#include <time.h>

clock_t t;

if(id==0){
  initialize...
}

t = clock();

while(notdone){
  JacobiSteps...
}
t = (clock()-t) -t;