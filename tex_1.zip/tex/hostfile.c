pc01 slots=4 max-slots=4 
pc02 slots=4 max-slots=4 
pc03 slots=4 max-slots=4 
.
.
.
pc011 slots=4 max-slots=4
