clc
clear all

N = 5000;
a = 20;

M=a*randn(N,N);
M=M+diag(sum(abs(M),2));

x=a*randn(N,1);

b=M*x;

A = [M b];

dlmwrite('At', A,'delimiter', '\t','newline','unix');
dlmwrite('xt',x,'delimiter', '\t','newline','unix');