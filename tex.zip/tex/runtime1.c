#include <time.h>

clock_t t;
t = clock();

if(id==0){
  initialize...
}

while(notdone){
  JacobiSteps...
}
t = (clock()-t) -t;