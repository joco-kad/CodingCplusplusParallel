typeset -i i END
let END=168000 i=0
while ((i<=END)); do
	plot ${i} w l
	let i = $(expr ${i} + 1000)
done
