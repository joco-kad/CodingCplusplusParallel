#start jacobi_mpi_07_07.cxx
#--------------------------
#shell script
#--------------------------

for c in ${seq 32}
do
	echo ${c} 
	time mpirun --hostfile my_hostfile -np ${c} ./jacobi 5kM Bx
done 
