JacobiStep(id*(n/tasks),(n/tasks));
if(rank==(tasks-1) && (n%tasks) != 0)
JacobiStep((id+1)*(n/tasks),n%tasks);
