    //Choose an initial guess x0 to the solution
    k = 0
    while (convergence not reached) 
	//Split i-loop among tasks        
	for (i := 1+rank*(n/tasks) repeat n/tasks times){ 
            h = 0
            for (j := 1 step until n){
                if (j != i)
                    h = h + a(i,j) x[i]
            }//end of (j-loop)
            x[i]_k+1 = (b[i]-h)/a(i,i)  
        }//end of (i-loop)
        //check if convergence is reached
        k = k + 1
   }
    
